/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matchup.servies;

import matchup.entities.user;

/**
 *
 * @author tpc
 */
public class Data {
    public static user user = new user();
}
