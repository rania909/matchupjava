/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import connection.myconnection;
import matchup.entities.proprietaire;
import matchup.servies.proprietaireCRUD;

//import Esprit.tools.MyConnection;
/**
 *
 * @author tpc
 */



    

public class test  {
    

  
    public static void main(String[] args) {
        myconnection mc = myconnection.getInstance();
//        proprietaireCRUD per = new proprietaireCRUD();
//        proprietaire p2 = new proprietaire("Foulen","Ben foulen","t","n","r",7,"f",7);
//        per.ajouterPersonne(p2);
    }
    
}
